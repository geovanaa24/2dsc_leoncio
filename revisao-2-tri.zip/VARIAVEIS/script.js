// # id ou identificador
// . class ou classe
const comidas = document.querySelector('.comidas');
// prompt → pergunta o usuario (interage)
const comida = prompt('Digite sua comida n°1:')

